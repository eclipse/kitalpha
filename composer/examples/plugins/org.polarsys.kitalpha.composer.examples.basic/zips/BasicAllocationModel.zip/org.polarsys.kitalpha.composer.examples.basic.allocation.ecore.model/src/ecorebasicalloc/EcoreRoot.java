package ecorebasicalloc;

import org.polarsys.kitalpha.composer.metamodel.allocation.base.Root;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ecore Root</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ecorebasicalloc.EcorebasicallocPackage#getEcoreRoot()
 * @model
 * @generated
 */
public interface EcoreRoot extends Root {
} // EcoreRoot
