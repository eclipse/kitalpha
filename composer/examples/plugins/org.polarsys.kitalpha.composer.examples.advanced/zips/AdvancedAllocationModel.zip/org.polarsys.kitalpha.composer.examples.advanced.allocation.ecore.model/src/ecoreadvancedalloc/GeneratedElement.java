package ecoreadvancedalloc;

import org.polarsys.kitalpha.composer.metamodel.allocation.base.Type;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Generated Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ecoreadvancedalloc.EcoreadvancedallocPackage#getGeneratedElement()
 * @model abstract="true"
 * @generated
 */
public interface GeneratedElement extends Type {
} // GeneratedElement
