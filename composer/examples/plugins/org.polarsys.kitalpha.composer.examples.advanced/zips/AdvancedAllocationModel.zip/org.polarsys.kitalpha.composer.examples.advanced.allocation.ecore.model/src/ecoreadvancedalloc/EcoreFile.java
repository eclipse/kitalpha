/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package ecoreadvancedalloc;

import org.polarsys.kitalpha.composer.metamodel.allocation.base.File;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ecore File</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ecoreadvancedalloc.EcoreadvancedallocPackage#getEcoreFile()
 * @model
 * @generated
 */
public interface EcoreFile extends File {
} // EcoreFile
