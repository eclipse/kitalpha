package ecoreadvancedalloc;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Forward Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ecoreadvancedalloc.EcoreadvancedallocPackage#getForwardDeclaration()
 * @model
 * @generated
 */
public interface ForwardDeclaration extends GeneratedElement {
} // ForwardDeclaration
