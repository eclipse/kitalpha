package ecoreadvancedalloc;

import org.polarsys.kitalpha.composer.metamodel.allocation.base.Root;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ecore Root</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ecoreadvancedalloc.EcoreadvancedallocPackage#getEcoreRoot()
 * @model
 * @generated
 */
public interface EcoreRoot extends Root {
} // EcoreRoot
