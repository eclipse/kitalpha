/**
 */
package ecorerecursivealloc;

import org.polarsys.kitalpha.composer.metamodel.allocation.base.Root;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ecore Alloc Root</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ecorerecursivealloc.EcorerecursiveallocPackage#getEcoreAllocRoot()
 * @model
 * @generated
 */
public interface EcoreAllocRoot extends Root {
} // EcoreAllocRoot
