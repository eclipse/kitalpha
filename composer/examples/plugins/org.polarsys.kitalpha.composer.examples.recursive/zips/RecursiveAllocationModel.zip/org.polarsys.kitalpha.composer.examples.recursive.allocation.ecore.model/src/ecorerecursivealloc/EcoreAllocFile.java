/**
 */
package ecorerecursivealloc;

import org.polarsys.kitalpha.composer.metamodel.allocation.base.File;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ecore Alloc File</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ecorerecursivealloc.EcorerecursiveallocPackage#getEcoreAllocFile()
 * @model
 * @generated
 */
public interface EcoreAllocFile extends File {
} // EcoreAllocFile
