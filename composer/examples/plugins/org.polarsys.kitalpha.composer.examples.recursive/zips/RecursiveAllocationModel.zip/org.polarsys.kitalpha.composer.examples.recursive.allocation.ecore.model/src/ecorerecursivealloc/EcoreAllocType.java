
package ecorerecursivealloc;

import org.polarsys.kitalpha.composer.metamodel.allocation.base.Type;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ecore Alloc Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ecorerecursivealloc.EcorerecursiveallocPackage#getEcoreAllocType()
 * @model
 * @generated
 */
public interface EcoreAllocType extends Type {
} // EcoreAllocType
