
package ecoreX;

import org.eclipse.emf.ecore.EPackage;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Extended EPackage</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ecoreX.EcoreXPackage#getExtendedEPackage()
 * @model
 * @generated
 */
public interface ExtendedEPackage extends EPackage {
} // ExtendedEPackage
