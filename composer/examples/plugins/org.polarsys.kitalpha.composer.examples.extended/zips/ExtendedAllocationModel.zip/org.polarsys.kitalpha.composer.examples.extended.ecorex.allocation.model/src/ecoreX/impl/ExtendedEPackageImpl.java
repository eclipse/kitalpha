/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package ecoreX.impl;

import ecoreX.EcoreXPackage;
import ecoreX.ExtendedEPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Extended EPackage</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ExtendedEPackageImpl extends EPackageImpl implements ExtendedEPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ExtendedEPackageImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return EcoreXPackage.Literals.EXTENDED_EPACKAGE;
	}

} //ExtendedEPackageImpl
