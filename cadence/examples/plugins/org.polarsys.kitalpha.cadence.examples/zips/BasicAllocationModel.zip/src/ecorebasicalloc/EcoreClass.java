/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package ecorebasicalloc;

import com.thalesgroup.mde.metamodel.allocation.base.Type;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ecore Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ecorebasicalloc.EcorebasicallocPackage#getEcoreClass()
 * @model
 * @generated
 */
public interface EcoreClass extends Type {
} // EcoreClass
