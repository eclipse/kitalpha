/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package ecorebasicalloc;

import com.thalesgroup.mde.metamodel.allocation.base.File;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ecore File</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ecorebasicalloc.EcorebasicallocPackage#getEcoreFile()
 * @model
 * @generated
 */
public interface EcoreFile extends File {
} // EcoreFile
