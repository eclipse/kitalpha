package com.thalesgroup.mde.metamodel.example.basicusecase.ecore.workflow.activities;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Map;

import javax.print.attribute.standard.Severity;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.thalesgroup.mde.cadence.core.api.IActivity;
import com.thalesgroup.mde.cadence.core.api.parameter.ActivityParameters;
import com.thalesgroup.mde.cadence.core.api.parameter.DeclaredParameter;
import com.thalesgroup.mde.cadence.core.api.parameter.ParameterError;
import com.thalesgroup.mde.metamodel.example.basicusecase.ecore.workflow.Activator;

public class DisplayTime implements IActivity {

	public DisplayTime() {
		// TODO Auto-generated constructor stub
	}

	public Collection<DeclaredParameter> getParameters() {
		// TODO Auto-generated method stub
		return null;
	}

	public IStatus run(ActivityParameters activityParams_p) {
		IStatus status = new Status(Severity.REPORT.getValue(), Activator.PLUGIN_ID, "");
		
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat dt = new SimpleDateFormat("HH'h' mm'min' ss'sec' SS'ms'");
		
		System.out.println("System time : " + dt.format(calendar.getTime()));
		
		return status;
	}

	public Map<String, ParameterError<?>> validateParameters(
			ActivityParameters valuedParameters_p) {
		// TODO Auto-generated method stub
		return null;
	}

}
